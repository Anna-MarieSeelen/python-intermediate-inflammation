"""Package containing the bulk of code for the patient data system."""
